<?php 
error_reporting(0);
include('phpqrcode/qrlib.php');


 if (isset($_POST['data'])) $data = $_POST['data'];
 else $data = "";
 ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>QR Code Generator</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<style>
#bimg::placeholder{
	font-size: 12px;
}
</style>

     <div class="container">

   	<form action="" method="POST" enctype="multipart/form-data">
     		<h1>QR Code Reader</h1>
     		<label>Select Qr Code File</label>
     		<input type="text"  id="bimg"
     		       name="barcode_img" placeholder="Copy and paste QrCode file name from qrcodes directory e.g 678cc96b7a444.png"
				   value="<?php echo $_POST['barcode_img']; ?>" />
				   
<br/><br/>

          		<button type="submit">Read QR Code</button>

     	</form>

		


     	<div class="qr" style="text-align:left">
			<?php if (isset($_POST['barcode_img']) && !empty($_POST['barcode_img'])) {
     			$image = $_POST['barcode_img'];
		?>
			<img src="qrcodes/<?php echo $_POST['barcode_img']; ?>" width=200 height=200/>
     		
		<?php

     			require __DIR__ . "/vendor/autoload.php";
              //  use Zxing\QrReader;
               // $qrcode = new QrReader('qrcodes/'.$image );
				$qrcode = new \Zxing\QrReader('qrcodes/'.$image );
                $text = $qrcode->text(); //return decoded text from QR Code
				echo '<p><pre>'.$text.'</pre></p>';
     		}else {
     			echo "<br>No data received!";
     		}
     		?>
     		<!-- ;extension=gd -->
     	</div>


		 <br/><br/>
		 <a href="index.php"><input type="button" name="generate" class="submit-button"
		 value="Create QrCode" style="background-color: black; color: #fff"/></a>
     </div>
</body>
</html>